//
//  ViewController.swift
//  JsonparsinginSwift
//
//  Created by Aravindakumar Arunachalam on 27/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        hitServer()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func hitServer()  {
        var dict_response = NSMutableDictionary()
        var contacts = NSMutableArray()
        var names = [String]()
        var email = [String]()
        var mobile = [String]()
        var phoneObj = NSMutableDictionary()
        var request = URLRequest(url:URL(string:"http://api.androidhive.info/contacts/")!)
        let session = URLSession.shared
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        let task = session.dataTask(with: request, completionHandler: {data, response, error -> Void           in
            guard error == nil && data != nil else
            {
                print("error=\(error)")
                return
            }
            do
            { try
                dict_response = JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSMutableDictionary
                print(dict_response)
               contacts = dict_response["contacts"]as! NSArray as! NSMutableArray
                
                for index in 0...contacts.count-1 {
                    let aObject = contacts[index] as! [String : AnyObject]
                    names.append(aObject["name"] as! String)
                    email.append(aObject["email"]as! String)
                    phoneObj=(aObject["phone"] as! NSMutableDictionary)
                    mobile.append(phoneObj["mobile"] as! String)
                }
                print("name is \(names)")
                print(email)
                print(mobile)
            }
            catch
            {
                print("Error Execption")
                DispatchQueue.main.async { () -> Void in
                    
                }
            }
            
            
        })
        task.resume()
    }

    }




